RAD_Noise 1.1
StudioDefense.com
Thank You For Your Support!

RAD_Noise
//an interactive sound toy 
//allows the user to create and export sounds in .WAV format.

Parameters:
Wave Type (Square, Saw, Sine, Noise) 
Frequency (Orange Left/Right)
Attack (Orange Up/Down)
Sustain (Red Left/Right)
Decay (Red Up/Down)
Vibrato Depth (Green Left/Right)
Vibrato Speed (Green Up/Down)
Phase Offset (Purple Left/Right)
Phase Slide (Purple Up/Down)
Slide (Blue Left/Right)
Delta Slide (Blue Up/Down)
Volume (Mouse Wheel Up/Down)